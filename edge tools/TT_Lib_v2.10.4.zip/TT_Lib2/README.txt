= TT_Lib2

* {SCF Thread}[http://forums.sketchucation.com/viewtopic.php?f=323&t=23307]

== Description

Library of common methods and classes for Google SketchUp Ruby plugins.

== Author

* Thomas Thomassen
* thomas[at]thomthom[dot]net