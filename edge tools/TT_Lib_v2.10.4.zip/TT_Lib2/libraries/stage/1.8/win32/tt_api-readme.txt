The tt_api.so file in this folder is a recompiled version of api.so from the 
Win32Utils API library.

Original version: http://win32utils.rubyforge.org/ ( Artistic License 2.0 )

This modified version is simply rewrapped under my own namespace:
TT::Win32::API

No other changes made. Please do not redistrubute, use the original version
instead as this version would be of no use for anyone else.

-Thomas Thomassen (www.thomthom.net)